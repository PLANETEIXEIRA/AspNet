

CREATE DATABASE [db_standBy]

use [db_standBy]

CREATE TABLE [dbo].[cliente](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[cnpj] [varchar](14) NULL,
	[Razao_social] [varchar](60) NULL,
	[Data_Fundacao] [datetime] NULL,
	[Capital] [decimal](18, 2) NULL,
	[Quarentena] [bit] NULL,
	[Status_Cliente] [bit] NULL,
	[Classificacao] [char](1) NULL,
 CONSTRAINT [PK_CLIENTE] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


