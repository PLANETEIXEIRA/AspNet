﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Sis.Dominio
{
    public class Clientes
    {

        [Display(Name = "Identificação")]
        public int Id { get; set; }

        [Required(ErrorMessage = "Razão Social é obrigatória")]
        [Display(Name = "Razão Social")]
        public string Razao_Social { get; set; }


        [Required(ErrorMessage = "Cnpj é obrigatório")]
        [StringLength(14, ErrorMessage = "Cnpj deve ter 14 dígitos .")]
        [Display(Name = "Cnpj")]

        public string Cnpj { get; set; }

        [Required(ErrorMessage = "Data da Fundacão é obrigatório")]
        [Display(Name = "Data da Fundacão")]
        [DataType(DataType.Date)]
        public DateTime Data_Fundacao { get; set; }

        [Required(ErrorMessage = "Capital é obrigatório")]
        [Display(Name = "Capital")]
        [DataType(DataType.Currency)]
        public decimal Capital { get; set; }

        public Boolean Quarentena { get; set; }
        [Display(Name = "Status")]

        public Boolean Status_Cliente { get; set; }
        [Display(Name = "Classificão")]
        public Char Classificacao { get; set; }



    }


}
