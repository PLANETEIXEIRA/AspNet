﻿using FluentValidation;
using System;

namespace Sis.Dominio.Validacao
{
    public class ValidaCliente : AbstractValidator<Clientes>
    {


        public ValidaCliente()
        {
            RuleFor(v => v.Razao_Social)
                .NotNull().WithMessage("A Razao Social do cliente não pode ser nula.");

            RuleFor(v => v.Data_Fundacao)
                .NotNull().WithMessage("A Data Fundação  não pode ser nula.")
                .LessThanOrEqualTo(DateTime.Today).WithMessage("A Data Fundação não pode estar no futuro.");


        }



    }

}
