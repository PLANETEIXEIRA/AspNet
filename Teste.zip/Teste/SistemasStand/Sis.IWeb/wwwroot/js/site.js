﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.


<script type="text/javascript" src="http://code.jquery.com/qunit/qunit-1.11.0.js"></script>
    <script type="text/javascript" src="~/lib/jquery/Mask/zepto.min.js"></script>
    <script type="text/javascript" src="~/lib/jquery/Mask/data.js"></script>
    <script type="text/javascript" src="~/lib/jquery/Mask/src/jquery.mask.js"></script>
    <script type="text/javascript" src="~/lib/jquery/Mask/jquery.mask.js"></script>

