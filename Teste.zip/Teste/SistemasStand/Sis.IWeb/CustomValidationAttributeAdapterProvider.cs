﻿namespace Sis.IWeb
{
    internal class CustomValidationAttributeAdapterProvider
    {
    }
}