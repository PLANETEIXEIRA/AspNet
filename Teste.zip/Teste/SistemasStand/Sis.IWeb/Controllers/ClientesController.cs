﻿using FluentValidation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sis.Dominio;
using Sis.Aplicacao.Interface;
using Sis.Dominio.Servico;
using Sis.Dominio.Validacao;
using System.Linq;
using System.Threading.Tasks;

namespace Sis.IWeb.Controllers
{
    public class ClientesController : Controller
    {
        private IRepositorio<Clientes> _repositorio;

        public ClientesController( IRepositorio<Clientes> repositorio)
        {
            _repositorio = repositorio;
        }

        public async Task<ActionResult> Index()
        {
            var clientes = _repositorio.Listar();
            return View(await clientes);
        }
         
        public async Task<ActionResult> Detalhes(int id)
        {
            var clientes = _repositorio.Selecionar(id);
            return View(await clientes);
        }

        public async Task<ActionResult> Filtrar(IFormCollection formCollection)
        {
            var clientes = _repositorio.Filtrar(formCollection["Cnpj"], formCollection["Razao"]);
            return View(await clientes);
        }


        public ActionResult Incluir()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Incluir(Clientes cliente)
        {
            ValidaCliente validador = new ValidaCliente();
            SIncluiCliente incluiCliente = new SIncluiCliente(cliente);

            bool validaCnpj = incluiCliente.ValidaCnpj(cliente.Cnpj);
            bool validaCadastro = incluiCliente.CnpjCadastrado(_repositorio, cliente);

            if (!validaCnpj)
            {
                ViewBag.erros = "Cnpj Invalido!";
                return View();
            }

            if (!validaCadastro)
            {
                ViewBag.erros = "Cnpj e Razão social cadastrado!";
                return View();
            }
            try
            {
                validador.ValidateAndThrow(cliente);
                _repositorio.Incluir(cliente);
                return RedirectToAction("Index");
            }
            catch (FluentValidation.ValidationException excecao)
            { 
                string ListaErros = "Cadastro inválido  ";
                excecao.Errors
                 .ToList()
                 .ForEach(e => ListaErros = ListaErros + $"{e.PropertyName} : {e.ErrorMessage}");

                ViewBag.erros = ListaErros;

                return View();
            }
        }

        public async Task<ActionResult> Alterar(int id)
        {
            var clientes = _repositorio.Selecionar(id);
            return View(await clientes);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Alterar( Clientes cliente)
        {
            ValidaCliente validador = new ValidaCliente();
            SIncluiCliente incluiCliente = new SIncluiCliente(cliente);

            bool validaCnpj = incluiCliente.ValidaCnpj(cliente.Cnpj);
            bool validaCadastro = incluiCliente.CnpjCadastrado(_repositorio, cliente);

            if (!validaCnpj)
            {
                ViewBag.erros = "Cnpj Invalido!";
                return View();
            }

            try
            {
                validador.ValidateAndThrow(cliente);
                _repositorio.Alterar(cliente);
                return RedirectToAction("Index");
            }
            catch  (FluentValidation.ValidationException excecao)
            {
                string ListaErros = "Cadastro inválido  ";
                excecao.Errors
                 .ToList()
                 .ForEach(e => ListaErros = ListaErros + $"{e.PropertyName} : {e.ErrorMessage}");

                ViewBag.erros = ListaErros;

                return View();
            }
        }

        public async Task<ActionResult> Apagar(int id)
        {
            var clientes = _repositorio.Selecionar(id);
            return View(await clientes);

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Apagar(int id, Clientes cliente)
        {
            ValidaCliente validador = new ValidaCliente();
            try
            {
       
                _repositorio.Excluir(cliente);
                return RedirectToAction("Index");
            }
            catch (FluentValidation.ValidationException excecao)
            {
                ViewBag.erros = excecao.Message.ToString();
                return View();
            }
        }
    }
}