﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Sis.Dominio;
using Sis.Aplicacao.Interface;
using Sis.Repositorio.Context;

namespace Sis.Repositorio.Repositorio
{
    public class RepositorioClientes : IRepositorio<Clientes>
    {
        private readonly MeuDbContext db;


        public RepositorioClientes(MeuDbContext meuDbContext)
        {
            db = meuDbContext;
        }

        public void Alterar(Clientes entidade)
        {
                var ClientesAltera = db.Cliente.First(x => x.Id == entidade.Id);
                ClientesAltera.Razao_Social = entidade.Razao_Social;
                ClientesAltera.Status_Cliente = entidade.Status_Cliente;
                ClientesAltera.Quarentena = entidade.Quarentena;
                ClientesAltera.Data_Fundacao = entidade.Data_Fundacao;
                ClientesAltera.Classificacao = entidade.Classificacao;
                ClientesAltera.Capital = entidade.Capital;
                
                db.SaveChanges();
          
        }

        public void Excluir(Clientes entidade)
        {
 
                db.Cliente.Remove(entidade);
                db.SaveChanges();
            
        }

        public Task<Clientes> Incluir(Clientes entidade)
        {
      
                db.Cliente.Add(entidade);
                db.SaveChanges();
            
            return  Selecionar(entidade.Id);
        }

        public async Task<List<Clientes>> Listar()
        {

   
                return await db.Cliente.OrderBy(x => x.Razao_Social ).Take(5)
                    .ToListAsync() ;
            
        }

        public async Task<Clientes> Selecionar(int id)
        {
        
       
                return await db.Cliente.AsNoTracking()
                    .FirstOrDefaultAsync(x => x.Id == id);
            
        }
        public async Task<List<Clientes>> Filtrar(string cnpj, string nome)
        {
      

                return await db.Cliente.Where( x => x.Cnpj.Contains(cnpj) && x.Razao_Social.Contains(nome)).ToListAsync();
              
            
        }
        public bool CnpjCadastrado(string cnpj, string nome )
        {

            var Id =  db.Cliente.Count(x => x.Cnpj == cnpj && x.Razao_Social == nome);  
            if (Id == 0)
                    return true;
                return false;
           
            
        }
    }
}
