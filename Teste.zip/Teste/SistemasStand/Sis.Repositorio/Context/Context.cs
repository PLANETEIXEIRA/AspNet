﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Protocols;
using Sis.Dominio;
using System.Configuration;


namespace Sis.Repositorio.Context
{
    public class MeuDbContext : DbContext
    {
      public DbSet<Clientes> Cliente { get; set; }

      public MeuDbContext(DbContextOptions<MeuDbContext> options) : base(options) { }

      protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }


    }
 }