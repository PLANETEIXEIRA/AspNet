﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Sis.Repositorio.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Clientes",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Razao_Social = table.Column<string>(nullable: false),
                    Cnpj = table.Column<string>(maxLength: 14, nullable: false),
                    Data_Fundacao = table.Column<DateTime>(nullable: false),
                    Capital = table.Column<decimal>(nullable: false),
                    Quarentena = table.Column<bool>(nullable: false),
                    Status_Cliente = table.Column<bool>(nullable: false),
                    Classificacao = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clientes", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Clientes");
        }
    }
}
