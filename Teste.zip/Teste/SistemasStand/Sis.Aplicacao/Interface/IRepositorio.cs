﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Sis.Aplicacao.Interface
{
    public interface IRepositorio<T> where T : class
    {
        void Alterar(T entidade);

        void Excluir(T entidade);

        Task<T> Incluir(T entidade);

        Task<T>  Selecionar(int id);

        Task<List<T>> Listar();

        bool CnpjCadastrado(String Cnpj, string Nome);

        Task<List<T>> Filtrar(String Cnpj, string Nome);

    }
}
